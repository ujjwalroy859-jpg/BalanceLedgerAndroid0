Balance Ledger Android project

Is ZIP mein Android Studio project hai; yeh APK file nahi hai.

APK banane ka tarika:
1. Computer par Android Studio install karein.
2. Android Studio mein "Open" chunein aur is ZIP ko extract karne ke baad BalanceLedgerAndroid folder kholein.
3. Gradle sync complete hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) chunein.
5. APK aam taur par app/build/outputs/apk/debug/app-debug.apk par milega.

App landscape mode mein khulta hai. Android wrapper mein native vibration bridge shamil hai.
